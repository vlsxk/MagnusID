import time
import re
from playwright.sync_api import Page, expect
from elements.button import Button
from elements.link import Link
from pages.base_page import BasePage
from components.authentication_form_component import AuthenticationFormComponent

class AuthenticationPage(BasePage):

    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.authentication_form = AuthenticationFormComponent(page)
        self.login_link = Link(page, "registration-page-login-link", "Login")  # Ссылка на страницу входа
        self.authentication_button = Button(page, "registration-page-registration-button",
                                          "Authentication")  # Кнопка отправки формы

    def click_authentication_button(self):
        """
        Клик на кнопку "Зарегистрироваться" и проверка перехода на страницу панели управления.

        :raises AssertionError: Если URL не соответствует ожидаемому
        """
        # Нажатие на кнопку регистрации
        self.authentication_button.click()
        # Проверка, что мы перенаправлены на страницу панели управления
        self.check_current_url(re.compile(".*/#/profile"))

    #     self.username_input = page.locator("#input_1")
    #     self.password_input = page.locator("#input_2")
    #     self.registration_button =page.locator('button', has_text='Войти')
    #     self.URL=AppRoute.AUTH
    #
    # def open_page(self) -> None:
    #     super().visit(self.URL)
    #
    # def check_visible_registration_form(self) -> None:
    #     expect(self.username_input).to_be_visible()
    #     expect(self.password_input).to_be_visible()
    #     expect(self.registration_button).to_be_visible()
    #
    # def fill_registration_form(self, username:str, password:str) -> None:
    #     self.username_input.fill(username)
    #     self.password_input.fill(password)
    # def click_registration_button(self):
    #     self.registration_button.click()
    #
    # def authorize(self, username:str, password:str) -> None:
    #     self.open_page()
    #     self.fill_registration_form(username, password)
    #     self.click_registration_button()
    #     time.sleep(2)
    #
    #
    #
