# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import base64
import hashlib
import json
import secrets
import shutil
import os
import sys
import warnings
import zipfile
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    List,
    Literal,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    Set,
    Tuple,
    Union,
    Pattern,
    cast,
)

import pytest

if sys.version_info >= (3, 11):
    _BaseExceptionGroup = BaseExceptionGroup  # noqa: F821
else:
    from exceptiongroup import BaseExceptionGroup as _BaseExceptionGroup

try:
    from playwright._impl._assertions import _soft_scope
except ImportError:
    _soft_scope = None
from playwright.sync_api import (
    APIRequestContext,
    Browser,
    BrowserContext,
    BrowserType,
    Error,
    Page,
    Playwright,
    sync_playwright,
    ProxySettings,
    StorageState,
    HttpCredentials,
    Geolocation,
    ViewportSize,
)
from slugify import slugify
import tempfile
import traceback
import urllib.parse


@pytest.fixture(scope="session")
def _pw_artifacts_folder(
    pytestconfig: Any,
) -> Generator[tempfile.TemporaryDirectory, None, None]:
    artifacts_folder = tempfile.TemporaryDirectory(prefix="playwright-pytest-")
    yield artifacts_folder

    def cleanup() -> None:
        try:
            # On Windows, files can be still in use.
            # https://github.com/microsoft/playwright-pytest/issues/163
            artifacts_folder.cleanup()
        except (PermissionError, NotADirectoryError):
            pass

    # Session fixtures are torn down during the last test's teardown, before its
    # artifacts are moved out of this folder in pytest_runtest_makereport.
    pytestconfig.add_cleanup(cleanup)


@pytest.fixture(scope="session", autouse=True)
def delete_output_dir(pytestconfig: Any) -> None:
    output_dir = pytestconfig.getoption("--output")
    if os.path.exists(output_dir):
        try:
            shutil.rmtree(output_dir)
        except (FileNotFoundError, PermissionError):
            # When running in parallel, another thread may have already deleted the files
            pass
        except OSError as error:
            if error.errno != 16:
                raise
            # We failed to remove folder, might be due to the whole folder being mounted inside a container:
            #   https://github.com/microsoft/playwright/issues/12106
            #   https://github.com/microsoft/playwright-python/issues/1781
            # Do a best-effort to remove all files inside of it instead.
            entries = os.listdir(output_dir)
            for entry in entries:
                shutil.rmtree(entry)


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_runtest_call(item: Any) -> Generator[None, Any, None]:
    if _soft_scope is None:
        yield
        return
    hard_failure: Optional[BaseException] = None
    with _soft_scope() as errors:
        try:
            yield
        except BaseException as exc:
            hard_failure = exc
    if not errors:
        if hard_failure is not None:
            raise hard_failure
        return
    if hard_failure is not None:
        raise _BaseExceptionGroup(
            "Test and soft assertion failures", [hard_failure, *errors]
        )
    if len(errors) == 1:
        raise errors[0]
    raise _BaseExceptionGroup("Soft assertion failures", errors)


# Fixtures defined by this plugin that (transitively) require a browser and
# therefore "browser_name". When one of them is requested through a user
# override of e.g. the "page" fixture, some pytest versions drop "browser_name"
# from the fixture closure, which would silently disable running the test
# against multiple browsers.
# https://github.com/microsoft/playwright-pytest/issues/172
_BROWSER_FIXTURES = ("page", "context", "new_context", "browser", "browser_type")


def pytest_generate_tests(metafunc: Any) -> None:
    if "browser_name" not in metafunc.fixturenames and any(
        name in metafunc.fixturenames for name in _BROWSER_FIXTURES
    ):
        metafunc.fixturenames.append("browser_name")
    if "browser_name" in metafunc.fixturenames:
        browsers = metafunc.config.option.browser or ["chromium"]
        metafunc.parametrize("browser_name", browsers, scope="session", indirect=True)


def pytest_configure(config: Any) -> None:
    config.addinivalue_line(
        "markers", "skip_browser(name): mark test to be skipped a specific browser"
    )
    config.addinivalue_line(
        "markers", "only_browser(name): mark test to run only on a specific browser"
    )
    config.addinivalue_line(
        "markers",
        "browser_context_args(**kwargs): provide additional arguments to browser.new_context()",
    )
    if config.getoption("--playwright-debug", default=None) == "cli":
        if getattr(config.option, "capture", "fd") != "no":
            raise pytest.UsageError(
                "--playwright-debug=cli requires disabled output capture "
                "(pass -s or --capture=no) so the attach command is visible."
            )
        worker_count = _xdist_worker_count(config)
        if worker_count is not None and worker_count != 1:
            raise pytest.UsageError(
                "--playwright-debug=cli requires a single worker "
                "(do not use pytest-xdist -n > 1)."
            )


# Set on a test item by _artifacts_recorder, picked up for the teardown report.
_ARTIFACTS_RECORDER_ATTR = "_playwright_artifacts_recorder"
# Node id of the test being set up, run or torn down, see _APIRequestContexts.
_CURRENT_TEST_NODEID_KEY = pytest.StashKey[str]()


# Making test result information available in fixtures
# https://docs.pytest.org/en/latest/example/simple.html#making-test-result-information-available-in-fixtures
#
# trylast: the code after `yield` of a trylast wrapper runs before that of the
# other wrappers, so pytest_runtest_makereport hooks in conftest.py and in other
# plugins see the teardown outcome set below. (A tryfirst wrapper elsewhere that
# changes rep.outcome after this point is not taken into account.)
@pytest.hookimpl(trylast=True, hookwrapper=True)
def pytest_runtest_makereport(item: Any) -> Generator[None, Any, None]:
    # execute all other hooks to obtain the report object
    outcome = yield
    rep = outcome.get_result()

    # set a report attribute for each phase of a call, which can
    # be "setup", "call", "teardown"

    if rep.when == "setup":
        # pytest-rerunfailures runs the same item again; forget the previous attempt.
        for when in ("call", "teardown"):
            if hasattr(item, f"rep_{when}"):
                delattr(item, f"rep_{when}")
    setattr(item, "rep_" + rep.when, rep)

    if rep.when == "teardown":
        artifacts_recorder = getattr(item, _ARTIFACTS_RECORDER_ATTR, None)
        if artifacts_recorder is not None:
            delattr(item, _ARTIFACTS_RECORDER_ATTR)
            try:
                if not artifacts_recorder.finished:
                    artifacts_recorder.did_finish_test(rep.failed)
            except Exception:
                # Report it as a teardown error of this test instead of letting it
                # escape the hook as an INTERNALERROR that aborts the session. A
                # fixture's own teardown error stays the main one.
                error = traceback.format_exc()
                if rep.failed:
                    rep.sections.append(("Playwright artifacts error", error))
                else:
                    rep.outcome = "failed"
                    rep.longrepr = error
            _attach_artifacts_to_report(item, rep, artifacts_recorder.artifacts)


def _test_failed_before_teardown(item: Any) -> bool:
    rep_call = getattr(item, "rep_call", None)
    if rep_call is not None:
        return rep_call.failed
    # No call report: the setup failed, the test was skipped from a fixture, or
    # the run was interrupted (then there is no teardown report either, so the
    # artifacts have to be kept right away).
    rep_setup = getattr(item, "rep_setup", None)
    return rep_setup is None or not rep_setup.skipped


def _attach_artifacts_to_report(
    item: Any, report: Any, artifacts: List[Tuple[str, str]]
) -> None:
    # Expose the kept artifacts to reporters. JUnit XML writes them as <property>
    # elements, one per artifact (so a name repeats for a test with e.g. several
    # contexts, like record_property() would), and pytest_runtest_logreport
    # hooks see them on the teardown report.
    config = item.config
    for kind, path in artifacts:
        report.user_properties.append(
            (f"playwright_{kind}", _path_for_report(config, path))
        )

    pytest_html = config.pluginmanager.getplugin("html")
    html_path = getattr(config.option, "htmlpath", None)
    if not artifacts or pytest_html is None or not html_path:
        return
    # pytest-html (>= 4) resolves --html like this, against the directory pytest
    # was started from.
    html_dir = Path(
        config.invocation_params.dir, Path(os.path.expandvars(html_path)).expanduser()
    ).parent

    def link(path: str) -> str:
        try:
            relative = os.path.relpath(path, html_dir)
        except ValueError:
            # Another drive on Windows, no relative link is possible.
            return Path(path).as_uri()
        return urllib.parse.quote(Path(relative).as_posix())

    self_contained = config.getoption("self_contained_html", default=False)
    extras = getattr(report, "extras", [])
    for kind, path in artifacts:
        if kind == "trace":
            extras.append(pytest_html.extras.url(link(path), name="Trace"))
            continue
        if self_contained:
            with open(path, "rb") as f:
                content = base64.b64encode(f.read()).decode()
        else:
            # Linked rather than embedded, so the report does not copy the file
            # into its assets folder.
            content = link(path)
        if kind == "screenshot":
            extras.append(pytest_html.extras.png(content, name="Screenshot"))
        elif kind == "video":
            extras.append(
                pytest_html.extras.video(
                    content, name="Video", mime_type="video/webm", extension="webm"
                )
            )
    report.extras = extras


def _path_for_report(config: Any, path: str) -> str:
    # Relative to the directory pytest was started from when the artifact is
    # inside it, so the path stays valid wherever the report is processed;
    # absolute otherwise.
    try:
        return str(Path(path).relative_to(config.invocation_params.dir))
    except ValueError:
        return path


def _get_skiplist(item: Any, values: List[str], value_name: str) -> List[str]:
    skipped_values: List[str] = []
    # Allowlist
    only_marker = item.get_closest_marker(f"only_{value_name}")
    if only_marker:
        skipped_values = values
        skipped_values.remove(only_marker.args[0])

    # Denylist
    skip_marker = item.get_closest_marker(f"skip_{value_name}")
    if skip_marker:
        skipped_values.append(skip_marker.args[0])

    return skipped_values


def pytest_runtest_setup(item: Any) -> None:
    item.config.stash[_CURRENT_TEST_NODEID_KEY] = item.nodeid
    if not hasattr(item, "callspec"):
        return
    browser_name = item.callspec.params.get("browser_name")
    if not browser_name:
        return

    skip_browsers_names = _get_skiplist(
        item, ["chromium", "firefox", "webkit"], "browser"
    )

    if browser_name in skip_browsers_names:
        pytest.skip("skipped for this browser: {}".format(browser_name))


VSCODE_PYTHON_EXTENSION_ID = "ms-python.python"


@pytest.fixture(scope="session")
def browser_type_launch_args(pytestconfig: Any, request: pytest.FixtureRequest) -> Dict:
    launch_options = {}
    headed_option = pytestconfig.getoption("--headed")
    if headed_option:
        launch_options["headless"] = False
    elif (
        VSCODE_PYTHON_EXTENSION_ID in sys.argv[0]
        and _is_debugger_attached()
        and _has_display()
    ):
        # When the VSCode debugger is attached, then launch the browser headed by default
        launch_options["headless"] = False
    browser_channel_option = pytestconfig.getoption("--browser-channel")
    if browser_channel_option:
        launch_options["channel"] = browser_channel_option
    slowmo_option = pytestconfig.getoption("--slowmo")
    if slowmo_option:
        launch_options["slow_mo"] = slowmo_option
    # Per-test launch options via
    # @pytest.mark.parametrize("browser_type_launch_args", [{...}], indirect=True)
    # override the command line options above. The fixture is session scoped, so
    # each distinct value launches its own browser.
    if hasattr(request, "param"):
        if not isinstance(request.param, Mapping):
            raise pytest.UsageError(
                "browser_type_launch_args expects a mapping of launch options, "
                f"got {type(request.param).__name__}: {request.param!r}"
            )
        launch_options.update(request.param)
    return launch_options


def _has_display() -> bool:
    # Remote / WSL / CI Linux machines often have no display server; launching
    # headed there fails, so only default to headed when a display is configured.
    # macOS and Windows always have one; elsewhere this checks the environment
    # variables, not that the display server is reachable.
    if sys.platform in ("darwin", "win32"):
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def _is_debugger_attached() -> bool:
    pydevd = sys.modules.get("pydevd")
    if not pydevd or not hasattr(pydevd, "get_global_debugger"):
        return False
    debugger = pydevd.get_global_debugger()
    if not debugger or not hasattr(debugger, "is_attached"):
        return False
    return debugger.is_attached()


@pytest.fixture
def output_path(pytestconfig: Any, request: pytest.FixtureRequest) -> str:
    output_dir = Path(pytestconfig.getoption("--output")).absolute()
    folder_name = slugify(request.node.nodeid)
    # pytest-rerunfailures runs failed tests again; keep each attempt's artifacts
    # in its own folder, like Playwright Test does.
    retry = getattr(request.node, "execution_count", 1) - 1
    if retry > 0:
        folder_name += f"-retry{retry}"
    return os.path.join(output_dir, _truncate_file_name(folder_name))


def _truncate_file_name(file_name: str) -> str:
    if len(file_name) < 256:
        return file_name
    return f"{file_name[:100]}-{hashlib.sha256(file_name.encode()).hexdigest()[:7]}-{file_name[-100:]}"


@pytest.fixture(scope="session")
def browser_context_args(
    pytestconfig: Any,
    playwright: Playwright,
    device: Optional[str],
    base_url: Optional[str],
    _pw_artifacts_folder: tempfile.TemporaryDirectory,
) -> Dict:
    context_args = {}
    if device:
        context_args.update(playwright.devices[device])
    if base_url:
        context_args["base_url"] = base_url

    video_option = pytestconfig.getoption("--video")
    capture_video = video_option in ["on", "retain-on-failure"]
    if capture_video:
        context_args["record_video_dir"] = _pw_artifacts_folder.name

    return context_args


@pytest.fixture()
def _artifacts_recorder(
    request: pytest.FixtureRequest,
    output_path: str,
    playwright: Playwright,
    pytestconfig: Any,
    _pw_artifacts_folder: tempfile.TemporaryDirectory,
    _pw_api_request_contexts: Optional["_APIRequestContexts"],
) -> Generator["ArtifactsRecorder", None, None]:
    artifacts_recorder = ArtifactsRecorder(
        pytestconfig,
        request,
        output_path,
        playwright,
        _pw_artifacts_folder,
        _pw_api_request_contexts,
    )
    artifacts_recorder.start_api_request_tracing()
    yield artifacts_recorder
    artifacts_recorder.stop_api_request_tracing()
    artifacts_recorder.collect_videos()
    if _test_failed_before_teardown(request.node):
        artifacts_recorder.did_finish_test(failed=True)
    # Otherwise fixtures torn down after this one (e.g. a user fixture that uses
    # `page`) can still fail the test, so pytest_runtest_makereport decides once
    # the teardown report exists. It also attaches the artifacts to that report.
    setattr(request.node, _ARTIFACTS_RECORDER_ATTR, artifacts_recorder)


@pytest.fixture(autouse=True)
def _pw_trace_api_requests(request: pytest.FixtureRequest) -> None:
    # Tests that only use playwright.request (no page or context) don't request
    # the artifacts recorder otherwise, and it records API request traces too.
    if (
        "playwright" in request.fixturenames
        and request.config.getoption("--tracing") != "off"
    ):
        request.getfixturevalue("_artifacts_recorder")


@pytest.fixture(scope="session")
def _pw_api_request_contexts(pytestconfig: Any) -> Optional["_APIRequestContexts"]:
    if pytestconfig.getoption("--tracing") == "off":
        return None
    return _APIRequestContexts(pytestconfig)


@pytest.fixture(scope="session")
def playwright(
    _pw_api_request_contexts: Optional["_APIRequestContexts"],
) -> Generator[Playwright, None, None]:
    pw = sync_playwright().start()
    if _pw_api_request_contexts:
        _pw_api_request_contexts.instrument(pw)
    yield pw
    pw.stop()


@pytest.fixture(scope="session")
def browser_type(playwright: Playwright, browser_name: str) -> BrowserType:
    return getattr(playwright, browser_name)


@pytest.fixture(scope="session")
def connect_options() -> Optional[Dict]:
    return None


@pytest.fixture(scope="session")
def launch_browser(
    browser_type_launch_args: Dict,
    browser_type: BrowserType,
    connect_options: Optional[Dict],
) -> Callable[..., Browser]:
    def launch(**kwargs: Dict) -> Browser:
        launch_options = {**browser_type_launch_args, **kwargs}
        if connect_options:
            browser = browser_type.connect(
                **(
                    {
                        **connect_options,
                        "headers": {
                            "x-playwright-launch-options": json.dumps(launch_options),
                            **(connect_options.get("headers") or {}),
                        },
                    }
                )
            )
        else:
            browser = browser_type.launch(**launch_options)
        return browser

    return launch


@pytest.fixture(scope="session")
def browser(launch_browser: Callable[[], Browser]) -> Generator[Browser, None, None]:
    browser = launch_browser()
    yield browser
    browser.close()


class CreateContextCallback(Protocol):
    def __call__(
        self,
        viewport: Optional[ViewportSize] = None,
        screen: Optional[ViewportSize] = None,
        no_viewport: Optional[bool] = None,
        ignore_https_errors: Optional[bool] = None,
        java_script_enabled: Optional[bool] = None,
        bypass_csp: Optional[bool] = None,
        user_agent: Optional[str] = None,
        locale: Optional[str] = None,
        timezone_id: Optional[str] = None,
        geolocation: Optional[Geolocation] = None,
        permissions: Optional[Sequence[str]] = None,
        extra_http_headers: Optional[Dict[str, str]] = None,
        offline: Optional[bool] = None,
        http_credentials: Optional[HttpCredentials] = None,
        device_scale_factor: Optional[float] = None,
        is_mobile: Optional[bool] = None,
        has_touch: Optional[bool] = None,
        color_scheme: Optional[
            Literal["dark", "light", "no-preference", "null"]
        ] = None,
        reduced_motion: Optional[Literal["no-preference", "null", "reduce"]] = None,
        forced_colors: Optional[Literal["active", "none", "null"]] = None,
        accept_downloads: Optional[bool] = None,
        default_browser_type: Optional[str] = None,
        proxy: Optional[ProxySettings] = None,
        record_har_path: Optional[Union[str, Path]] = None,
        record_har_omit_content: Optional[bool] = None,
        record_video_dir: Optional[Union[str, Path]] = None,
        record_video_size: Optional[ViewportSize] = None,
        storage_state: Optional[Union[StorageState, str, Path]] = None,
        base_url: Optional[str] = None,
        strict_selectors: Optional[bool] = None,
        service_workers: Optional[Literal["allow", "block"]] = None,
        record_har_url_filter: Optional[Union[str, Pattern[str]]] = None,
        record_har_mode: Optional[Literal["full", "minimal"]] = None,
        record_har_content: Optional[Literal["attach", "embed", "omit"]] = None,
    ) -> BrowserContext: ...


@pytest.fixture
def new_context(
    browser: Browser,
    browser_context_args: Dict,
    _artifacts_recorder: "ArtifactsRecorder",
    request: pytest.FixtureRequest,
) -> Generator[CreateContextCallback, None, None]:
    browser_context_args = browser_context_args.copy()
    context_args_marker = next(request.node.iter_markers("browser_context_args"), None)
    additional_context_args = context_args_marker.kwargs if context_args_marker else {}
    browser_context_args.update(additional_context_args)
    contexts: List[BrowserContext] = []
    debug_cli = request.config.getoption("--playwright-debug", default=None) == "cli"

    def _new_context(**kwargs: Any) -> BrowserContext:
        context = browser.new_context(**browser_context_args, **kwargs)
        original_close = context.close

        def _close_wrapper(*args: Any, **kwargs: Any) -> None:
            contexts.remove(context)
            _artifacts_recorder.on_will_close_browser_context(context)
            original_close(*args, **kwargs)

        context.close = _close_wrapper
        if (
            debug_cli and not contexts
        ):  # CLI attach drives contexts()[0] only — bind/print/pause on first context.
            _run_debug_cli(browser, context, str(request.config.rootpath))
        contexts.append(context)
        _artifacts_recorder.on_did_create_browser_context(context)
        return context

    yield cast(CreateContextCallback, _new_context)
    for context in contexts.copy():
        context.close()


@pytest.fixture
def context(new_context: CreateContextCallback) -> BrowserContext:
    return new_context()


@pytest.fixture
def page(context: BrowserContext) -> Page:
    return context.new_page()


@pytest.fixture(scope="session")
def is_webkit(browser_name: str) -> bool:
    return browser_name == "webkit"


@pytest.fixture(scope="session")
def is_firefox(browser_name: str) -> bool:
    return browser_name == "firefox"


@pytest.fixture(scope="session")
def is_chromium(browser_name: str) -> bool:
    return browser_name == "chromium"


@pytest.fixture(scope="session")
def browser_name(pytestconfig: Any, request: pytest.FixtureRequest) -> Optional[str]:
    if hasattr(request, "param"):
        return request.param

    # When using unittest.TestCase it won't use pytest_generate_tests
    # For that we still try to give the user a slightly less feature-rich experience
    browser_names = pytestconfig.getoption("--browser")
    if len(browser_names) == 0:
        return "chromium"
    if len(browser_names) == 1:
        return browser_names[0]
    warnings.warn(
        "When using unittest.TestCase specifying multiple browsers is not supported"
    )
    return browser_names[0]


@pytest.fixture(scope="session")
def browser_channel(pytestconfig: Any) -> Optional[str]:
    return pytestconfig.getoption("--browser-channel")


@pytest.fixture(scope="session")
def device(pytestconfig: Any) -> Optional[str]:
    return pytestconfig.getoption("--device")


PW_ASYNC_CANONICAL_NAME = "pytest_playwright_asyncio.pytest_playwright"
PLUGIN_INCOMPATIBLE_MESSAGE = "pytest-playwright and pytest-playwright-asyncio are not compatible. Please use only one of them."


def _run_debug_cli(
    browser: Browser, context: BrowserContext, workspace_dir: str
) -> None:
    if (
        not callable(getattr(browser, "bind", None))
        or getattr(context, "debugger", None) is None
    ):
        raise pytest.UsageError("--playwright-debug=cli requires playwright>=1.59")

    session_name = f"tw-{secrets.token_hex(3)}"
    browser.bind(session_name, workspace_dir=workspace_dir)

    # Leading newline: with -s, pytest prints "test_foo.py " with no trailing
    # newline before fixtures run; start our banner on its own line.
    print(
        "\n### The test is currently paused at the start\n"
        "\n"
        "### Debugging Instructions\n"
        f"- Run `python -m playwright cli attach {session_name}` "
        "to attach to this test\n",
        flush=True,
    )

    context.set_default_timeout(0)
    context.set_default_navigation_timeout(0)
    context.debugger.request_pause()


def _xdist_worker_count(config: Any) -> Optional[int]:
    numprocesses = getattr(config.option, "numprocesses", None)
    if numprocesses is None:
        return None
    if numprocesses == "logical" or numprocesses == "auto":
        return 2
    try:
        return int(numprocesses)
    except (TypeError, ValueError):
        return 2


def pytest_addoption(
    parser: pytest.Parser, pluginmanager: pytest.PytestPluginManager
) -> None:
    # Check for incompatible async plugin with canonical name
    if pluginmanager.has_plugin(PW_ASYNC_CANONICAL_NAME):
        raise RuntimeError(PLUGIN_INCOMPATIBLE_MESSAGE)
    # Check for incompatible async plugin with common name
    common_name_plugin = pluginmanager.get_plugin("playwright-asyncio")
    if (
        common_name_plugin is not None
        and pluginmanager.get_canonical_name(common_name_plugin)
        == PW_ASYNC_CANONICAL_NAME
    ):
        raise RuntimeError(PLUGIN_INCOMPATIBLE_MESSAGE)
    group = parser.getgroup("playwright", "Playwright")
    group.addoption(
        "--browser",
        action="append",
        default=[],
        help="Browser engine which should be used",
        choices=["chromium", "firefox", "webkit"],
    )
    group.addoption(
        "--headed",
        action="store_true",
        default=False,
        help="Run tests in headed mode.",
    )
    group.addoption(
        "--browser-channel",
        action="store",
        default=None,
        help="Browser channel to be used.",
    )
    group.addoption(
        "--slowmo",
        default=0,
        type=int,
        help="Run tests with slow mo",
    )
    group.addoption(
        "--device",
        default=None,
        action="store",
        help="Device to be emulated.",
    )
    group.addoption(
        "--output",
        default="test-results",
        help="Directory for artifacts produced by tests, defaults to test-results.",
    )
    group.addoption(
        "--tracing",
        default="off",
        choices=["on", "off", "retain-on-failure"],
        help="Whether to record a trace for each test.",
    )
    group.addoption(
        "--video",
        default="off",
        choices=["on", "off", "retain-on-failure"],
        help="Whether to record video for each test.",
    )
    group.addoption(
        "--screenshot",
        default="off",
        choices=["on", "off", "only-on-failure"],
        help="Whether to automatically capture a screenshot after each test.",
    )
    group.addoption(
        "--full-page-screenshot",
        action="store_true",
        default=False,
        help="Whether to take a full page screenshot",
    )
    group.addoption(
        "--playwright-debug",
        default=None,
        choices=["cli"],
        help="Enable Playwright CLI debugging. Requires -s/--capture=no.",
    )


@pytest.hookimpl(hookwrapper=True)
def pytest_load_initial_conftests(
    early_config: Any, parser: pytest.Parser
) -> Generator[None, None, None]:
    yield
    # By now every plugin is registered: from -p, PYTEST_PLUGINS, the entry points
    # (unless autoloading is disabled) and the initial conftests. So this is the
    # first point where it is known whether pytest-base-url is in use, and options
    # can still be added, as the command line is parsed afterwards.
    if _is_pytest_base_url_loaded(early_config.pluginmanager):
        return
    # pytest-base-url is optional (pip install pytest-playwright[base-url]). When
    # it is not in use, provide the same option, ini value and fixture.
    parser.addini("base_url", help="base url for the application under test.")
    parser.getgroup("playwright", "Playwright").addoption(
        "--base-url",
        metavar="url",
        default=os.getenv("PYTEST_BASE_URL", None),
        help="base url for the application under test.",
    )
    early_config.pluginmanager.register(_BaseUrlFallback(), "playwright-base-url")


def _is_pytest_base_url_loaded(pluginmanager: pytest.PytestPluginManager) -> bool:
    # Registered as "base_url" through its entry point, or under its module name
    # with -p pytest_base_url.plugin; checking the module covers both.
    module = sys.modules.get("pytest_base_url.plugin")
    return module is not None and pluginmanager.is_registered(module)


class _BaseUrlFallback:
    # Provides the base_url fixture when pytest-base-url is not in use.
    @pytest.fixture(scope="session")
    def base_url(self, pytestconfig: Any) -> Optional[str]:
        return (
            pytestconfig.getoption("--base-url")
            or pytestconfig.getini("base_url")
            or None
        )


class ArtifactsRecorder:
    def __init__(
        self,
        pytestconfig: Any,
        request: pytest.FixtureRequest,
        output_path: str,
        playwright: Playwright,
        pw_artifacts_folder: tempfile.TemporaryDirectory,
        api_request_contexts: Optional["_APIRequestContexts"] = None,
    ) -> None:
        self._request = request
        self._api_request_contexts = api_request_contexts
        self._pytestconfig = pytestconfig
        self._playwright = playwright
        self._output_path = output_path
        self._pw_artifacts_folder = pw_artifacts_folder

        self._all_pages: List[Page] = []
        self._screenshots: List[str] = []
        self._traces: List[str] = []
        # API request contexts that existed before this test, see start_api_request_tracing.
        self._shared_api_request_contexts: Set[APIRequestContext] = set()
        # (temporary path, file name in the output folder)
        self._videos: List[Tuple[str, str]] = []
        self.finished = False
        # (kind, path) of the artifacts kept in the output folder
        self.artifacts: List[Tuple[str, str]] = []
        self._tracing_option = pytestconfig.getoption("--tracing")
        self._capture_trace = self._tracing_option in ["on", "retain-on-failure"]

    def _build_artifact_test_folder(self, folder_or_file_name: str) -> str:
        return os.path.join(
            self._output_path,
            _truncate_file_name(folder_or_file_name),
        )

    def did_finish_test(self, failed: bool) -> None:
        self.finished = True
        screenshot_option = self._pytestconfig.getoption("--screenshot")
        capture_screenshot = screenshot_option == "on" or (
            failed and screenshot_option == "only-on-failure"
        )
        if capture_screenshot:
            for index, screenshot in enumerate(self._screenshots):
                human_readable_status = "failed" if failed else "finished"
                screenshot_path = self._build_artifact_test_folder(
                    f"test-{human_readable_status}-{index + 1}.png",
                )
                os.makedirs(os.path.dirname(screenshot_path), exist_ok=True)
                shutil.move(screenshot, screenshot_path)
                self.artifacts.append(("screenshot", screenshot_path))
        else:
            for screenshot in self._screenshots:
                os.remove(screenshot)

        if self._tracing_option == "on" or (
            failed and self._tracing_option == "retain-on-failure"
        ):
            for index, trace in enumerate(self._traces):
                trace_file_name = (
                    "trace.zip" if len(self._traces) == 1 else f"trace-{index + 1}.zip"
                )
                trace_path = self._build_artifact_test_folder(trace_file_name)
                os.makedirs(os.path.dirname(trace_path), exist_ok=True)
                shutil.move(trace, trace_path)
                self.artifacts.append(("trace", trace_path))
        else:
            for trace in self._traces:
                os.remove(trace)

        video_option = self._pytestconfig.getoption("--video")
        preserve_video = video_option == "on" or (
            failed and video_option == "retain-on-failure"
        )
        for video, video_file_name in self._videos:
            if preserve_video:
                video_path = self._build_artifact_test_folder(video_file_name)
                os.makedirs(os.path.dirname(video_path), exist_ok=True)
                shutil.move(video, video_path)
                self.artifacts.append(("video", video_path))
            else:
                os.remove(video)

    def collect_videos(self) -> None:
        # Videos are only complete once their context is closed. Copy them out of
        # Playwright now, so that keeping or discarding them later is file work only.
        if self._pytestconfig.getoption("--video") not in ["on", "retain-on-failure"]:
            return
        for index, page in enumerate(self._all_pages):
            try:
                video = page.video
                if not video:
                    continue
                video_path = Path(self._pw_artifacts_folder.name) / _create_guid()
                video.save_as(path=video_path)
            except Error:
                # Silent catch empty videos.
                continue
            video_file_name = (
                "video.webm" if len(self._all_pages) == 1 else f"video-{index + 1}.webm"
            )
            self._videos.append((str(video_path), video_file_name))
            try:
                video.delete()
            except Error:
                # The copy is what gets kept; removing Playwright's file is best effort.
                pass

    def on_did_create_browser_context(self, context: BrowserContext) -> None:
        context.on("page", lambda page: self._all_pages.append(page))
        if self._request and self._capture_trace:
            context.tracing.start(
                title=slugify(self._request.node.nodeid),
                screenshots=True,
                snapshots=True,
                sources=True,
            )

    def on_will_close_browser_context(self, context: BrowserContext) -> None:
        if self._capture_trace:
            trace_path = Path(self._pw_artifacts_folder.name) / _create_guid()
            context.tracing.stop(path=trace_path)
            self._traces.append(str(trace_path))
        else:
            context.tracing.stop()

        if self._pytestconfig.getoption("--screenshot") in ["on", "only-on-failure"]:
            for page in context.pages:
                try:
                    screenshot_path = (
                        Path(self._pw_artifacts_folder.name) / _create_guid()
                    )
                    page.screenshot(
                        timeout=5000,
                        path=screenshot_path,
                        type="png",
                        full_page=self._pytestconfig.getoption(
                            "--full-page-screenshot"
                        ),
                    )
                    self._screenshots.append(str(screenshot_path))
                except Error:
                    pass

    def start_api_request_tracing(self) -> None:
        contexts = self._api_request_contexts
        if contexts is None:
            return
        contexts.recorder = self
        # Contexts from before this test, e.g. session-scoped ones: their trace is
        # only kept when the test used them. Contexts the test creates itself keep
        # their trace, like browser contexts do.
        self._shared_api_request_contexts = set(contexts.live)
        for context in contexts.live:
            if context not in contexts.tracing_chunk:
                context.tracing.start_chunk(title=slugify(self._request.node.nodeid))
                contexts.tracing_chunk.add(context)

    def stop_api_request_tracing(self) -> None:
        contexts = self._api_request_contexts
        if contexts is None:
            return
        contexts.recorder = None
        for context in contexts.live:
            self.on_will_dispose_api_request_context(context)

    def on_will_dispose_api_request_context(self, context: APIRequestContext) -> None:
        contexts = self._api_request_contexts
        if contexts is None or context not in contexts.tracing_chunk:
            return
        # Forgotten first: should stop_chunk fail (the error is reported like one
        # from a browser context), the next start_chunk discards what is still
        # being recorded.
        contexts.tracing_chunk.discard(context)
        trace_path = Path(self._pw_artifacts_folder.name) / _create_guid()
        context.tracing.stop_chunk(path=trace_path)
        if context in self._shared_api_request_contexts and not _trace_has_actions(
            trace_path
        ):
            os.remove(trace_path)
            return
        self._traces.append(str(trace_path))


class _APIRequestContexts:
    # Tracks contexts created via playwright.request.new_context() so that, like
    # browser contexts, their traces are recorded per test.

    def __init__(self, config: Any) -> None:
        self._config = config
        self.live: List[APIRequestContext] = []
        # Contexts with a trace chunk in progress.
        self.tracing_chunk: Set[APIRequestContext] = set()
        # Recorder of the running test, if any.
        self.recorder: Optional[ArtifactsRecorder] = None

    def instrument(self, playwright: Playwright) -> None:
        # playwright.request is one APIRequest instance for the lifetime of the
        # Playwright object, so wrapping its method here covers all contexts.
        original_new_context = playwright.request.new_context

        def _new_context(*args: Any, **kwargs: Any) -> APIRequestContext:
            context = original_new_context(*args, **kwargs)
            if getattr(context, "tracing", None) is None:
                # APIRequestContext.tracing requires playwright>=1.60.
                return context
            original_dispose = context.dispose

            def _dispose_wrapper(*args: Any, **kwargs: Any) -> None:
                if context in self.live:
                    self.live.remove(context)
                try:
                    if self.recorder is not None:
                        self.recorder.on_will_dispose_api_request_context(context)
                    self.tracing_chunk.discard(context)
                finally:
                    # Dispose even if saving the trace failed; that error still
                    # propagates.
                    original_dispose(*args, **kwargs)

            context.dispose = _dispose_wrapper
            # Contexts are usually created by fixtures, before the artifacts
            # recorder of the test exists, so the title comes from the hook.
            nodeid = self._config.stash.get(_CURRENT_TEST_NODEID_KEY, None)
            context.tracing.start(
                title=slugify(nodeid) if nodeid else None,
                screenshots=True,
                snapshots=True,
                sources=True,
            )
            self.live.append(context)
            self.tracing_chunk.add(context)
            return context

        playwright.request.new_context = _new_context


def _trace_has_actions(trace_path: Path) -> bool:
    # Looks for an action ("before" event) in the trace. The format (one JSON
    # event per line in *.trace) is Playwright's own and may change, in which
    # case, or on any error, the trace is kept.
    try:
        with zipfile.ZipFile(trace_path) as trace:
            for name in trace.namelist():
                if not name.endswith(".trace"):
                    continue
                with trace.open(name) as events:
                    for event in events:
                        if b'"type":"before"' in event:
                            return True
        return False
    except (OSError, zipfile.BadZipFile):
        return True


def _create_guid() -> str:
    return hashlib.sha256(os.urandom(16)).hexdigest()
