import allure
from playwright.sync_api import Page

from components.base_component import BaseComponent
from elements.input import Input


class AuthenticationFormComponent(BaseComponent):
    """
    Компонент формы регистрации. Содержит поля: Email, Username, Password.
    Предоставляет методы для заполнения и проверки отображения формы.
    """

    def __init__(self, page: Page):
        """
        Инициализирует элемент формы регистрации.

        :param page: Экземпляр Playwright Page
        """

        super().__init__(page)


        self.username_input = Input(page, "login-input-username", "Username")
        # Поле ввода password
        self.password_input = Input(page, "login-input-password", "Password")

    @allure.step("Fill registration form")
    def fill(self, username: str, password: str):
        """
        Заполняет форму регистрации заданными значениями.

        :param email: Email пользователя
        :param username: Имя пользователя
        :param password: Пароль
        """


        # Заполнение username и проверка, что значение введено корректно
        self.username_input.fill(username)
        self.username_input.check_have_value(username)

        # Заполнение password и проверка, что значение введено корректно
        self.password_input.fill(password)
        self.password_input.check_have_value(password)

    @allure.step("Check that registration form is visible")
    def check_visible(self, username: str, password: str):
        """
        Проверяет, что форма регистрации отображается корректно и содержит указанные значения.

        :param email: Ожидаемое значение email
        :param username: Ожидаемое значение username
        :param password: Ожидаемое значение пароля
        """

        # Проверка username-поля
        self.username_input.check_visible()
        self.username_input.check_have_value(username)

        # Проверка password-поля
        self.password_input.check_visible()
        self.password_input.check_have_value(password)